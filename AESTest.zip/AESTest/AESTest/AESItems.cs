﻿using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;



class AESItems
{
    public static string AES_Key = "rnop3TnHwJ7P9zzLb0Z3qUjfhu1Cx9bW";
    public static string AES_IV = "YsiebTh0Sjr8dZKo";



    public string AESEncypt(string MainText)
    {
        AesCryptoServiceProvider aesCrypto = new AesCryptoServiceProvider();

        byte[] textbytes = ASCIIEncoding.ASCII.GetBytes(MainText);

        aesCrypto.BlockSize = 128;
        aesCrypto.KeySize = 256;
        aesCrypto.IV = ASCIIEncoding.ASCII.GetBytes(AES_IV);
        aesCrypto.Key = ASCIIEncoding.ASCII.GetBytes(AES_Key);
        aesCrypto.Mode = CipherMode.CFB;
        aesCrypto.Padding = PaddingMode.PKCS7;

        ICryptoTransform cripter = aesCrypto.CreateEncryptor(aesCrypto.Key, aesCrypto.IV);

        byte[] abc = cripter.TransformFinalBlock(textbytes, 0, textbytes.Length);
        cripter.Dispose();
        return Convert.ToBase64String(abc);


        //byte[] Mainbytes = Encoding.Unicode.GetBytes(MainText);

        //using (ICryptoTransform encrypt = aesCrypto.CreateEncryptor())
        //{
        //    byte[] Encryptedbytes = encrypt.TransformFinalBlock(Mainbytes, 0, Mainbytes.Length);

        //    return Convert.ToBase64String(Encryptedbytes);
        //}

    }

    public string AESDecrypt(string encryptedText,byte[] iv,string key)
    {
       

        byte[] textbytes = Convert.FromBase64String(encryptedText);

        using (Aes aesCrypto = Aes.Create())
        {
            aesCrypto.Mode = CipherMode.CFB;
            aesCrypto.Key = Encoding.ASCII.GetBytes(key);
            aesCrypto.IV = iv;
            aesCrypto.Padding = PaddingMode.None;

            ICryptoTransform cripter = aesCrypto.CreateDecryptor(aesCrypto.Key, aesCrypto.IV);

            using (MemoryStream memoryStream = new MemoryStream(textbytes))
            {
                using (CryptoStream cryptoStream =
                    new CryptoStream((Stream) memoryStream, cripter, CryptoStreamMode.Read))
                {
                    using (StreamReader streamReader = new StreamReader((Stream) cryptoStream))
                    {
                        return streamReader.ReadToEnd();
                    }
                }
            }
        }
    }




    //byte[] EncryptedTextBytes = Convert.FromBase64String(EncryptedText);
    //using (ICryptoTransform decrypt = aesCrypto.CreateDecryptor())
    //{
    //    byte[] DecryptedTextBytes = decrypt.TransformFinalBlock(EncryptedTextBytes, 0, EncryptedTextBytes.Length);

    //    return Encoding.Unicode.GetString(DecryptedTextBytes);
    //}

}



