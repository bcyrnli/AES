﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            var a = AesEncoder.AESDecrypt("p4psltayVQ7eTjVEfXVhJh2KMl3BCeHj8eJz7OvWjpNVLbwsqDeIp492KHNqlD54w/FTTFLIYxb4ABTEZfCj3r7uT4PDWWZMjhQ=", Encoding.ASCII.GetBytes("YsiebTh0Sjr8dZKo"), "rnop3TnHwJ7P9zzLb0Z3qUjfhu1Cx9bW");

            Console.WriteLine(a);
        }
        
        }

    }

