﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ConsoleApp1
{
    public static class AesEncoder
    {
        public static string AESDecrypt(string encryptedText, byte[] iv, string key)
        {


            byte[] textbytes = Convert.FromBase64String(encryptedText);

            using (Aes aesCrypto = Aes.Create())
            {
                aesCrypto.Mode = CipherMode.CFB;
                aesCrypto.Key = Encoding.ASCII.GetBytes(key);
                aesCrypto.IV = iv;
                aesCrypto.Padding = PaddingMode.None;

                ICryptoTransform cripter = aesCrypto.CreateDecryptor(aesCrypto.Key, aesCrypto.IV);

                using (MemoryStream memoryStream = new MemoryStream(textbytes))
                {
                    using (CryptoStream cryptoStream =
                        new CryptoStream((Stream) memoryStream, cripter, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader((Stream) cryptoStream))
                        {
                            return streamReader.ReadToEnd();
                        }
                    }
                }
            }
        }
    }
}