﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsoleApp1;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonEncrypt_Click(object sender, EventArgs e)
        {
            var encryptedText = AesEncoder.AESEncypt(richTextBoxPlainText.Text,
                Encoding.UTF8.GetBytes(AesEncoder.AesIv), AesEncoder.AesKey);

            richTextBoxEncryptedText.Text = encryptedText;
        }

        private void buttonDecrypt_Click(object sender, EventArgs e)
        {
            var decryptedText = AesEncoder.AESDecrypt(richTextBoxEncryptedText.Text,
                Encoding.UTF8.GetBytes(AesEncoder.AesIv), AesEncoder.AesKey);

            richTextBoxDecryptedText.Text = decryptedText;
        }
    }
}
